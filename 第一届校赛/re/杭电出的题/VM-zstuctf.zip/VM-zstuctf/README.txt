Title: babyVM

Description:
In the world of Rev@CTF, VM is very common. Here is a basic VM without any tricky things, you can have a try.

Attachment: vm-binary-stripped

==============================================================

Hint1:
Every instruction in this VM takes up 4 bytes:

+---------+---------+---------+---------+
| OP_CODE |  ARG_1  |  ARG_2  |  ARG_3  |
+---------+---------+---------+---------+
low                                  high

==============================================================

Hint2:
Oops, Professor Snape had made a mistake, the unstripped version accidentally leaked. And he said, the instructions of this VM is similar to the ones of MIPS.

New Attachment: vm-binary-unstripped

==============================================================

Hint3:
In the lastest <Witch Weekly>, a mystery man has published some strange spells:

// 00 call _xor
// 04 terminate
//    _xor:
// 08 li $2, 32
// 12 li $3, 1
//    _start:
// 16 beq $2, $0, _ret
// 20 sub $2, $2, $3
// 24 lb $1, $2
// 28 xor $1, $1, $2
// 32 sb $2, $1
// 36 jmp _start
//    _ret:
// 40 ret

