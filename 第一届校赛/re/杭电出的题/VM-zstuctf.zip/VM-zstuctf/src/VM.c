#include "VM.h"
#include <string.h>
#include <stdio.h>

VM_State state;


void init_vm(void) {
  state.MEM = NULL;
  state.IP = state.RET_TO = 0;
  state.REGS[0] = state.REGS[1] = state.REGS[2] = state.REGS[3] = 0;
}


void start_vm(const uint8_t vm_code[], uint8_t buf[]) {
  state.MEM = buf;

  uint8_t opcode;
  while ((opcode = vm_code[state.IP]) != TERMINATE) {
    switch (opcode) {
      case LI:   li(vm_code[state.IP+1], vm_code[state.IP+2]); break;
      case LB:   lb(vm_code[state.IP+1], vm_code[state.IP+2]); break;
      case SB:   sb(vm_code[state.IP+1], vm_code[state.IP+2]); break;
      case SUB:  sub(vm_code[state.IP+1], vm_code[state.IP+2], vm_code[state.IP+3]); break;
      case XOR:  xor(vm_code[state.IP+1], vm_code[state.IP+2], vm_code[state.IP+3]); break;
      case JMP:  jmp(vm_code[state.IP+1]); break;
      case BEQ:  beq(vm_code[state.IP+1], vm_code[state.IP+2], vm_code[state.IP+3]); break;
      case CALL: call(vm_code[state.IP+1]); break;
      case RET:  ret(); break;
      default:
        printf("unrecognized opcode: %#x\n", (uint8_t) opcode);
    }
    state.IP += 4;
  }
}


void li(uint8_t RD, uint8_t RS) {
#ifdef DEBUG
  printf("li $%u, %u\n", RD, RS);
#endif
  if (RD == 0) return;

  state.REGS[RD] = RS;
}

void lb(uint8_t RD, uint8_t RS) {
#ifdef DEBUG
  printf("lb $%u, MEM[$%u]\n", RD, RS);
#endif
  if (RD == 0) return;

  state.REGS[RD] = state.MEM[state.REGS[RS]];
}

void sb(uint8_t RD, uint8_t RS) {
#ifdef DEBUG
  printf("sb MEM[$%u], $%u\n", RD, RS);
#endif
  state.MEM[state.REGS[RD]] = state.REGS[RS];
}

void sub(uint8_t RD, uint8_t RS, uint8_t RT) {
#ifdef DEBUG
  printf("sub $%u, $%u, $%u\n", RD, RS, RT);
#endif
  state.REGS[RD] = state.REGS[RS] - state.REGS[RT];
}

void xor(uint8_t RD, uint8_t RS, uint8_t RT) {
#ifdef DEBUG
  printf("xor $%u, $%u, $%u\n", RD, RS, RT);
#endif
  state.REGS[RD] = state.REGS[RS] ^ state.REGS[RT];
}

void jmp(uint8_t RD) {
#ifdef DEBUG
  printf("jmp %u\n", RD);
#endif
  state.IP = RD - 4;  // compensate for auto-increment
}

void beq(uint8_t RD, uint8_t RS, uint8_t RT) {
#ifdef DEBUG
  printf("beq $%u, $%u, %u\n", RS, RT, RD);
#endif
  if (state.REGS[RS] == state.REGS[RT]) {
    state.IP = RD - 4;  // compensate for auto-increment
  }
}

void call(uint8_t RD) {
#ifdef DEBUG
  printf("call %u\n", RD);
#endif
  state.RET_TO = state.IP;
  state.IP = RD - 4;    // compensate for auto-increment
}

void ret(void) {
#ifdef DEBUG
  printf("ret\n");
#endif
  state.IP = state.RET_TO;
}
