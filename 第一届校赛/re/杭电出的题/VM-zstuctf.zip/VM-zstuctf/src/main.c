
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include "VM.h"

// zstuctf{N3V3R__5T0P_UR_PR0GR35S}

const uint8_t correct[] = {
    0x7a, 0x72, 0x76, 0x76, 0x67, 0x71, 0x60, 0x7c,
    0x46, 0x3a, 0x5c, 0x38, 0x5e, 0x52, 0x51, 0x3a,
    0x44, 0x21, 0x42, 0x4c, 0x41, 0x47, 0x49, 0x47,
    0x4a, 0x29, 0x5d, 0x49, 0x2f, 0x28, 0x4d, 0x62,
    0x00,
};


#define _xor 8
#define _start 16
#define _ret 40

const VM_Code opcode[] = {
    Instruction(CALL, _xor, 0, 0),        // 00 call _xor
    Instruction(TERMINATE, 0, 0, 0),      // 04 terminate
                                          //    _xor:
    Instruction(LI, 2, 32, 0),            // 08 li $2, 32
    Instruction(LI, 3, 1, 0),             // 12 li $3, 1
                                          //    _start:
    Instruction(BEQ, _ret, 2, 0),         // 16 beq $2, $0, _ret
    Instruction(SUB, 2, 2, 3),            // 20 sub $2, $2, $3
    Instruction(LB, 1, 2, 0),             // 24 lb $1, $2
    Instruction(XOR, 1, 1, 2),            // 28 xor $1, $1, $2
    Instruction(SB, 2, 1, 0),             // 32 sb $2, $1
    Instruction(JMP, _start, 0, 0),       // 36 jmp _start
                                          //    _ret:
    Instruction(RET, 0, 0, 0),            // 40 ret
};


void read_n(char *to, size_t n) {
  while (n--) {
    if (read(0, to, 1) <= 0 || *to == '\n')
      break;
    to++;
  }
  *to = 0;
}


int main() {
  init_vm();

  puts("Cast your spell here to prove that you're not a muggle: ");
  char buf[33];
  read_n(buf, 32);

  start_vm((uint8_t *) opcode, (uint8_t *) buf);

#ifdef DEBUG
  for (int i = 0; i < 32; ++i)
    printf("%#x, ", (uint8_t) buf[i]);
  puts("");
#endif

  if ((strcmp(buf, (char*)correct) == 0)) {
    puts("Wow, welcome to Hogwarts");
    return 0;

  } else {
    puts("Muggle! Get out!");
    return -1;
  }
}