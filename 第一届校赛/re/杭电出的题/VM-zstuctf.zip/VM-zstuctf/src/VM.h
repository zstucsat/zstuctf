#ifndef VM_VM_H
#define VM_VM_H

#include <ctype.h>
#include <stdint.h>
#include <stdbool.h>

typedef uint32_t VM_Code;

#define TERMINATE   0x0u
#define LI          0x1u
#define LB          0x2u
#define SB          0x3u
#define SUB         0x4u
#define XOR         0x5u
#define JMP         0x6u
#define BEQ         0x7u
#define CALL        0x8u
#define RET         0x9u

#define BYTE(x) ((uint8_t)x & 0xff)
#define Instruction(OP_CODE, RD, RS, RT) \
  ((BYTE(OP_CODE) << 0) | (BYTE(RD) << 8) | (BYTE(RS) << 16) | (BYTE(RT) << 24))


typedef struct {
  uint8_t *MEM;
  uint8_t IP;
  uint8_t RET_TO;
  uint8_t REGS[4];
} VM_State;


void init_vm(void);
void start_vm(const uint8_t [], uint8_t []);

void li(uint8_t, uint8_t);
void lb(uint8_t, uint8_t);
void sb(uint8_t, uint8_t);
void sub(uint8_t, uint8_t, uint8_t);
void xor(uint8_t, uint8_t, uint8_t);
void jmp(uint8_t);
void beq(uint8_t, uint8_t, uint8_t);
void call(uint8_t);
void ret(void);


#endif //VM_VM_H